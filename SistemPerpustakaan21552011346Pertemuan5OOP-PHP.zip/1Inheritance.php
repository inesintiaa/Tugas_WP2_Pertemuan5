<?php
// kelas utama
class LibraryItem {
    protected $title;
    protected $available = true;

    public function __construct($title) {
        $this->title = $title;
    }

    public function getTitle() {
        return $this->title;
    }

    public function isAvailable() {
        return $this->available;
    }

    public function borrow() {
        if ($this->available) {
            $this->available = false;
            echo "Item '{$this->title}' telah dipinjam.\n";
        } else {
            echo "Maaf, '{$this->title}' sudah tidak tersedia.\n";
        }
    }

    public function returnItem() {
        if (!$this->available) {
            $this->available = true;
            echo "Item '{$this->title}' telah dikembalikan.\n";
        } else {
            echo "Error! '{$this->title}' sudah tersedia.\n";
        }
    }

    public function displayAvailability() {
        $status = $this->available ? "tersedia" : "tidak tersedia";
        echo "Item '{$this->title}' is $status.\n";
    }
}

class Book extends LibraryItem {
    private $author;

    public function __construct($title, $author) {
        parent::__construct($title);
        $this->author = $author;
    }

    public function getAuthor() {
        return $this->author;
    }

    public function displayDetails() {
        echo "Judul: {$this->title}\n";
        echo "Penulis: {$this->author}\n";
        $this->displayAvailability();
    }
}

class Library {
    private $items = [];

    public function addItem(LibraryItem $item) {
        $this->items[] = $item;
        echo "Item '{$item->getTitle()}' telah ditambahkan kedalam library.\n";
    }

    public function listAvailableBooks() {
        echo "Buku yang tersedia:\n";
        foreach ($this->items as $item) {
            if ($item instanceof Book && $item->isAvailable()) {
                echo "- {$item->getTitle()} by {$item->getAuthor()}\n";
            }
        }
    }
}

// Contoh penggunaan
$library = new Library();

// Menambahkan buku
$book1 = new Book("Hujan", "Tere Liye");
$book2 = new Book("Pulang", "Tere Liye");
$library->addItem($book1);
$library->addItem($book2);

// Meminjam buku
$book1->borrow();

// Menampilkan daftar buku yang tersedia
$library->listAvailableBooks();

// Mengembalikan buku
$book1->returnItem();