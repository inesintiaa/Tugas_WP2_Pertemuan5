<?php
// kelas dengan enkapsulasi

class Book {
    private $judul;
    private $penulis;
    private $isAvailable;

    public function __construct($judul, $penulis) {
        $this->judul = $judul;
        $this->penulis = $penulis;
        $this->isAvailable = true;
    }

    public function getTitle() {
        return $this->judul;
    }

    public function getAuthor() {
        return $this->penulis;
    }

    public function isAvailable() {
        return $this->isAvailable;
    }

    public function borrowBook() {
        $this->isAvailable = false;
    }

    public function returnBook() {
        $this->isAvailable = true;
    }
}
// Penggunaan enkapsulasi
$book1 = new Book("Hujan", "Tere Liye");
$book2 = new Book("Pulang", "Tere Liye");
echo $library->addItem($book1);
echo $library->addItem($book2);

?>